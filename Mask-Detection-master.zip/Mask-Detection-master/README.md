# Mask-Detection
This is a mask detection project which uses tensorflow to detect if a person is wearing mask or not.
